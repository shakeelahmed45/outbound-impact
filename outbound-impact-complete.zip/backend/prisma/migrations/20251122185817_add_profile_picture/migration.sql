-- AlterTable
ALTER TABLE "User" ADD COLUMN     "profilePicture" TEXT;
