import { useState, useEffect } from 'react';
import { TrendingUp, Eye, FolderOpen, BarChart3, Download, FileText, Clock } from 'lucide-react';
import DashboardLayout from '../components/dashboard/DashboardLayout';
import api from '../services/api';

const AnalyticsPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showExportToast, setShowExportToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const response = await api.get('/analytics');
      if (response.data.status === 'success') {
        setAnalytics(response.data.analytics);
      }
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = () => {
    setToastMessage('📄 CSV Export feature coming soon!');
    setShowExportToast(true);
    setTimeout(() => setShowExportToast(false), 3000);
  };

  const handleExportPDF = () => {
    setToastMessage('📑 PDF Report feature coming soon!');
    setShowExportToast(true);
    setTimeout(() => setShowExportToast(false), 3000);
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div>
        {/* Toast Notification */}
        {showExportToast && (
          <div className="fixed top-4 right-4 z-50 animate-slideIn">
            <div className="bg-blue-600 text-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3">
              <div className="text-2xl">ℹ️</div>
              <p className="font-semibold">{toastMessage}</p>
            </div>
          </div>
        )}

        {/* Header with Export Buttons */}
        <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-primary mb-2">Analytics Dashboard</h1>
            <p className="text-secondary">Track your content performance and engagement</p>
          </div>
          
          {/* EXPORT BUTTONS */}
          <div className="flex gap-3">
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-2 px-5 py-3 bg-white border-2 border-green-500 text-green-600 rounded-xl font-semibold hover:bg-green-50 transition-all shadow-lg hover:shadow-xl"
            >
              <Download size={20} />
              <span>Export CSV</span>
            </button>
            <button
              onClick={handleExportPDF}
              className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-xl font-semibold hover:shadow-2xl transform hover:scale-105 transition-all"
            >
              <FileText size={20} />
              <span>Export PDF</span>
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                <Eye size={24} className="text-white" />
              </div>
            </div>
            <p className="text-3xl font-bold text-primary mb-1">
              {analytics?.totalViews || 0}
            </p>
            <p className="text-sm text-gray-600">Total Views</p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
                <BarChart3 size={24} className="text-white" />
              </div>
            </div>
            <p className="text-3xl font-bold text-primary mb-1">
              {analytics?.totalItems || 0}
            </p>
            <p className="text-sm text-gray-600">Total Items</p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center">
                <FolderOpen size={24} className="text-white" />
              </div>
            </div>
            <p className="text-3xl font-bold text-primary mb-1">
              {analytics?.campaignStats?.length || 0}
            </p>
            <p className="text-sm text-gray-600">Active Campaigns</p>
          </div>
        </div>

        {/* REDESIGNED ACTIVITY BY TIME OF DAY CARD */}
        <div className="bg-gradient-to-br from-orange-50 via-red-50 to-pink-50 rounded-3xl shadow-2xl p-8 border-2 border-orange-200 mb-8 relative overflow-hidden">
          {/* Decorative Background */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-orange-300/20 to-red-300/20 rounded-full -mr-48 -mt-48 blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-pink-300/20 to-orange-300/20 rounded-full -ml-48 -mb-48 blur-3xl"></div>
          
          <div className="relative z-10">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center shadow-xl">
                  <Clock size={32} className="text-white" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent mb-1">
                    Activity by Time of Day
                  </h3>
                  <p className="text-gray-700 font-medium">Discover your peak engagement hours</p>
                </div>
              </div>
              
              <div className="bg-white/80 backdrop-blur-sm px-6 py-3 rounded-xl border-2 border-orange-300 shadow-lg">
                <p className="text-sm text-orange-700 font-bold">🚀 Coming Soon</p>
                <p className="text-xs text-gray-600">Advanced Analytics</p>
              </div>
            </div>

            {/* Chart Area */}
            <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-8 border-2 border-white shadow-xl">
              {/* 24 Hour Visualization */}
              <div className="mb-8">
                <div className="flex items-end justify-between h-64 gap-1">
                  {Array.from({ length: 24 }).map((_, hour) => {
                    const isBusinessHour = hour >= 9 && hour <= 17;
                    const isPeakTime = hour === 14 || hour === 15;
                    const heightPercent = isPeakTime ? 90 : isBusinessHour ? 60 : 30;
                    
                    return (
                      <div key={hour} className="flex-1 flex flex-col items-center gap-2">
                        <div className="w-full flex flex-col items-center justify-end h-full">
                          <div className="relative w-full group">
                            {/* Tooltip */}
                            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
                              <div className="bg-gray-900 text-white text-xs py-2 px-3 rounded-lg whitespace-nowrap shadow-xl">
                                <p className="font-bold">{String(hour).padStart(2, '0')}:00</p>
                                <p className="text-gray-300">Data coming soon</p>
                              </div>
                            </div>
                            
                            {/* Bar */}
                            <div 
                              className={`w-full rounded-t-lg transition-all duration-500 cursor-pointer ${
                                isPeakTime
                                  ? 'bg-gradient-to-t from-orange-600 to-red-600 shadow-lg'
                                  : isBusinessHour
                                    ? 'bg-gradient-to-t from-orange-500 to-red-500'
                                    : 'bg-gradient-to-t from-orange-300 to-red-300 opacity-50'
                              }`}
                              style={{ height: `${heightPercent}%` }}
                            ></div>
                          </div>
                        </div>
                        
                        {/* Hour Label */}
                        {hour % 4 === 0 && (
                          <p className="text-xs text-gray-600 font-bold">
                            {String(hour).padStart(2, '0')}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Time Labels */}
                <div className="flex justify-between text-sm text-gray-700 font-bold mt-4 px-2">
                  <span>Midnight</span>
                  <span>Morning</span>
                  <span>Noon</span>
                  <span>Evening</span>
                  <span>Night</span>
                </div>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-gradient-to-br from-orange-100 to-orange-200 p-4 rounded-xl border-2 border-orange-300 text-center">
                  <p className="text-xs text-orange-700 font-semibold mb-1">Peak Hour</p>
                  <p className="text-2xl font-bold text-orange-900">--:--</p>
                  <p className="text-xs text-orange-600 mt-1">Coming Soon</p>
                </div>
                
                <div className="bg-gradient-to-br from-red-100 to-red-200 p-4 rounded-xl border-2 border-red-300 text-center">
                  <p className="text-xs text-red-700 font-semibold mb-1">Peak Views</p>
                  <p className="text-2xl font-bold text-red-900">--</p>
                  <p className="text-xs text-red-600 mt-1">Coming Soon</p>
                </div>
                
                <div className="bg-gradient-to-br from-yellow-100 to-yellow-200 p-4 rounded-xl border-2 border-yellow-300 text-center">
                  <p className="text-xs text-yellow-700 font-semibold mb-1">Avg/Hour</p>
                  <p className="text-2xl font-bold text-yellow-900">--</p>
                  <p className="text-xs text-yellow-600 mt-1">Coming Soon</p>
                </div>
                
                <div className="bg-gradient-to-br from-pink-100 to-pink-200 p-4 rounded-xl border-2 border-pink-300 text-center">
                  <p className="text-xs text-pink-700 font-semibold mb-1">Active Hours</p>
                  <p className="text-2xl font-bold text-pink-900">--</p>
                  <p className="text-xs text-pink-600 mt-1">Coming Soon</p>
                </div>
              </div>

              {/* Coming Soon Banner */}
              <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-6 rounded-xl text-center shadow-lg">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <Clock size={32} className="animate-pulse" />
                  <h4 className="text-xl font-bold">Advanced Hourly Analytics Coming Soon!</h4>
                </div>
                <p className="text-orange-100 mb-4 text-sm">
                  We're building powerful time-of-day analytics to show exactly when your audience is most active
                </p>
                <div className="flex flex-wrap items-center justify-center gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                    <span>Peak hour detection</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                    <span>Hourly patterns</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                    <span>Time zone insights</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content by Type & Campaign Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <h3 className="text-xl font-bold text-primary mb-6">Content by Type</h3>
            {analytics?.itemsByType && Object.keys(analytics.itemsByType).length > 0 ? (
              <div className="space-y-4">
                {Object.entries(analytics.itemsByType).map(([type, count]) => {
                  const total = analytics.totalItems || 1;
                  const percentage = Math.round((count / total) * 100);
                  return (
                    <div key={type}>
                      <div className="flex justify-between mb-2">
                        <span className="font-medium text-gray-700">{type}</span>
                        <span className="text-primary font-semibold">{count} items</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className="bg-gradient-to-r from-primary to-secondary h-3 rounded-full transition-all"
                          style={{ width: percentage + '%' }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">No items yet</p>
            )}
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <h3 className="text-xl font-bold text-primary mb-6">Campaign Performance</h3>
            {analytics?.campaignStats && analytics.campaignStats.length > 0 ? (
              <div className="space-y-4">
                {analytics.campaignStats.map((campaign) => (
                  <div key={campaign.id} className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                    <div>
                      <p className="font-semibold text-gray-800">{campaign.name}</p>
                      <p className="text-sm text-gray-600">{campaign.itemCount} items</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">{campaign.views}</p>
                      <p className="text-xs text-gray-600">views</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">No campaigns yet</p>
            )}
          </div>
        </div>

        {/* Recent Items */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <h3 className="text-xl font-bold text-primary mb-6">Recent Items</h3>
          {analytics?.recentItems && analytics.recentItems.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Title</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Type</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Campaign</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Views</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Created</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {analytics.recentItems.map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium text-gray-800">{item.title}</td>
                      <td className="py-3 px-4">
                        <span className="px-3 py-1 bg-purple-100 text-primary rounded-full text-sm">
                          {item.type}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-600">
                        {item.campaign ? item.campaign.name : '-'}
                      </td>
                      <td className="py-3 px-4 font-semibold text-primary">{item.views}</td>
                      <td className="py-3 px-4 text-gray-600 text-sm">
                        {new Date(item.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">No items yet</p>
          )}
        </div>
      </div>

      {/* Add animations to global CSS */}
      <style>{`
        @keyframes slideIn {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
        .animate-slideIn {
          animation: slideIn 0.3s ease-out;
        }
      `}</style>
    </DashboardLayout>
  );
};

export default AnalyticsPage;
