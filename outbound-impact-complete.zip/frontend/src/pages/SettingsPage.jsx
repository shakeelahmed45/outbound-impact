import { useState } from 'react';
import { User, CreditCard, Shield, LogOut, Upload, Trash2, MessageSquare, Send } from 'lucide-react';
import DashboardLayout from '../components/dashboard/DashboardLayout';
import useAuthStore from '../store/authStore';
import api from '../services/api';
import { useToast } from '../hooks/useToast';
import Toast from '../components/common/Toast';

const SettingsPage = () => {
  const { user, logout, setUser } = useAuthStore();
  const { toasts, showToast, removeToast } = useToast();
  const [activeTab, setActiveTab] = useState('profile');
  const [loading, setLoading] = useState(false);
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
  });
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  // Feedback state
  const [feedbackData, setFeedbackData] = useState({
    subject: '',
    message: '',
  });
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  const handleLogout = () => {
    logout();
    window.location.href = '/signin';
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await api.put('/user/profile', profileData);
      if (response.data.status === 'success') {
        setUser(response.data.user);
        showToast('Profile updated successfully!', 'success');
      }
    } catch (error) {
      console.error('Failed to update profile:', error);
      showToast('Failed to update profile', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Please select an image file', 'error');
      return;
    }

    setUploadingPhoto(true);
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64Data = e.target.result;
        const response = await api.post('/user/profile-picture', { imageData: base64Data });
        
        if (response.data.status === 'success') {
          setUser(response.data.user);
          showToast('Profile picture updated!', 'success');
        }
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Failed to upload photo:', error);
      showToast('Failed to upload photo', 'error');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleDeletePhoto = async () => {
    if (!confirm('Are you sure you want to delete your profile picture?')) return;

    try {
      const response = await api.delete('/user/profile-picture');
      if (response.data.status === 'success') {
        setUser(response.data.user);
        showToast('Profile picture deleted', 'success');
      }
    } catch (error) {
      console.error('Failed to delete photo:', error);
      showToast('Failed to delete photo', 'error');
    }
  };

  // Handle Feedback Submission
  const handleSubmitFeedback = async (e) => {
    e.preventDefault();
    
    if (!feedbackData.subject || !feedbackData.message) {
      showToast('Please fill in all fields', 'error');
      return;
    }

    setSubmittingFeedback(true);
    try {
      const response = await api.post('/feedback', feedbackData);
      if (response.data.status === 'success') {
        showToast('Feedback submitted successfully! We\'ll review it soon.', 'success');
        setFeedbackData({ subject: '', message: '' });
      }
    } catch (error) {
      console.error('Failed to submit feedback:', error);
      showToast('Failed to submit feedback', 'error');
    } finally {
      setSubmittingFeedback(false);
    }
  };

  // Open Live Chat
  const handleOpenLiveChat = () => {
    // Navigate to live chat page
    window.location.href = '/live-chat';
  };

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'subscription', label: 'Subscription', icon: CreditCard },
    { id: 'feedback', label: 'Feedback', icon: MessageSquare },
    { id: 'chat', label: 'Live Chat', icon: Send },
    { id: 'security', label: 'Security', icon: Shield },
  ];

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">Settings</h1>
          <p className="text-secondary">Manage your account settings and preferences</p>
        </div>

        {/* Toast Container */}
        <div className="fixed top-4 right-4 z-50 space-y-2">
          {toasts.map((toast) => (
            <Toast
              key={toast.id}
              message={toast.message}
              type={toast.type}
              onClose={() => removeToast(toast.id)}
            />
          ))}
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Tabs Sidebar */}
          <div className="md:w-64">
            <div className="bg-white rounded-2xl shadow-lg p-4">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all mb-2 ${
                      activeTab === tab.id
                        ? 'bg-gradient-to-r from-primary to-secondary text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon size={20} />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                );
              })}
              
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 transition-all mt-4"
              >
                <LogOut size={20} />
                <span className="font-medium">Logout</span>
              </button>
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1">
            <div className="bg-white rounded-2xl shadow-lg p-8">
              {/* Profile Tab */}
              {activeTab === 'profile' && (
                <div>
                  <h2 className="text-2xl font-bold text-primary mb-6">Profile Information</h2>
                  
                  {/* Profile Picture */}
                  <div className="mb-8">
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      Profile Picture
                    </label>
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        {user?.profilePicture ? (
                          <img
                            src={user.profilePicture}
                            alt="Profile"
                            className="w-24 h-24 rounded-full object-cover border-4 border-primary"
                          />
                        ) : (
                          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-3xl font-bold border-4 border-primary">
                            {user?.name?.charAt(0).toUpperCase()}
                          </div>
                        )}
                        {uploadingPhoto && (
                          <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full flex items-center justify-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
                          </div>
                        )}
                      </div>
                      <div>
                        <label className="cursor-pointer inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg hover:bg-opacity-90 transition-all">
                          <Upload size={16} />
                          <span>Upload New</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handlePhotoUpload}
                            className="hidden"
                            disabled={uploadingPhoto}
                          />
                        </label>
                        {user?.profilePicture && (
                          <button
                            onClick={handleDeletePhoto}
                            className="ml-2 inline-flex items-center gap-2 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-all"
                          >
                            <Trash2 size={16} />
                            <span>Delete</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Profile Form */}
                  <form onSubmit={handleUpdateProfile} className="space-y-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Full Name
                      </label>
                      <input
                        type="text"
                        value={profileData.name}
                        onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={profileData.email}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 cursor-not-allowed"
                        disabled
                      />
                      <p className="text-sm text-gray-500 mt-1">Email cannot be changed</p>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Account Type
                      </label>
                      <input
                        type="text"
                        value={user?.role?.replace('_', ' ')}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 capitalize cursor-not-allowed"
                        disabled
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-gradient-to-r from-primary to-secondary text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all disabled:opacity-50"
                    >
                      {loading ? 'Updating...' : 'Update Profile'}
                    </button>
                  </form>
                </div>
              )}

              {/* Subscription Tab */}
              {activeTab === 'subscription' && (
                <div>
                  <h2 className="text-2xl font-bold text-primary mb-6">Subscription</h2>
                  <div className="bg-gradient-to-br from-purple-50 to-violet-50 rounded-xl p-6 mb-6">
                    <h3 className="text-xl font-bold text-primary mb-2">Current Plan</h3>
                    <p className="text-2xl font-bold text-secondary mb-4 capitalize">
                      {user?.role?.replace('ORG_', '').replace('_', ' ')}
                    </p>
                    <p className="text-gray-600 mb-4">
                      Status: <span className="font-semibold text-green-600">Active</span>
                    </p>
                  </div>
                  <a
                    href="/plans"
                    className="inline-block bg-gradient-to-r from-primary to-secondary text-white px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition-all"
                  >
                    Manage Subscription
                  </a>
                </div>
              )}

              {/* Feedback Tab */}
              {activeTab === 'feedback' && (
                <div>
                  <h2 className="text-2xl font-bold text-primary mb-2">Send Feedback</h2>
                  <p className="text-secondary mb-6">We'd love to hear your thoughts and suggestions!</p>
                  
                  <form onSubmit={handleSubmitFeedback} className="space-y-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Subject
                      </label>
                      <input
                        type="text"
                        value={feedbackData.subject}
                        onChange={(e) => setFeedbackData({ ...feedbackData, subject: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="What is your feedback about?"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Message
                      </label>
                      <textarea
                        value={feedbackData.message}
                        onChange={(e) => setFeedbackData({ ...feedbackData, message: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent h-40 resize-none"
                        placeholder="Tell us more about your feedback..."
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={submittingFeedback}
                      className="w-full bg-gradient-to-r from-primary to-secondary text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {submittingFeedback ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                          <span>Submitting...</span>
                        </>
                      ) : (
                        <>
                          <Send size={20} />
                          <span>Submit Feedback</span>
                        </>
                      )}
                    </button>
                  </form>

                  <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-sm text-blue-800">
                      <strong>Note:</strong> We review all feedback carefully and will get back to you if needed. Thank you for helping us improve!
                    </p>
                  </div>
                </div>
              )}

              {/* Live Chat Tab */}
              {activeTab === 'chat' && (
                <div>
                  <h2 className="text-2xl font-bold text-primary mb-2">Live Chat Support</h2>
                  <p className="text-secondary mb-6">Chat with our support team in real-time</p>
                  
                  <div className="bg-gradient-to-br from-purple-50 to-violet-50 rounded-xl p-8 text-center">
                    <div className="w-20 h-20 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                      <MessageSquare size={40} className="text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-primary mb-2">Need Help?</h3>
                    <p className="text-gray-600 mb-6">
                      Our support team is here to help you with any questions or issues.
                    </p>
                    <button
                      onClick={handleOpenLiveChat}
                      className="bg-gradient-to-r from-primary to-secondary text-white px-8 py-3 rounded-lg font-semibold hover:shadow-lg transition-all inline-flex items-center gap-2"
                    >
                      <MessageSquare size={20} />
                      <span>Start Live Chat</span>
                    </button>
                  </div>

                  <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-white border border-gray-200 rounded-lg">
                      <h4 className="font-semibold text-gray-800 mb-2">⚡ Fast Response</h4>
                      <p className="text-sm text-gray-600">Get answers to your questions in minutes</p>
                    </div>
                    <div className="p-4 bg-white border border-gray-200 rounded-lg">
                      <h4 className="font-semibold text-gray-800 mb-2">💬 Real-Time Chat</h4>
                      <p className="text-sm text-gray-600">Talk directly with our support team</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Security Tab */}
              {activeTab === 'security' && (
                <div>
                  <h2 className="text-2xl font-bold text-primary mb-6">Security Settings</h2>
                  <div className="space-y-6">
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h3 className="font-semibold text-gray-800 mb-2">Change Password</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Update your password to keep your account secure
                      </p>
                      <button className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-opacity-90 transition-all">
                        Change Password
                      </button>
                    </div>

                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h3 className="font-semibold text-gray-800 mb-2">Two-Factor Authentication</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Add an extra layer of security to your account
                      </p>
                      <button className="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition-all">
                        Enable 2FA
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default SettingsPage;
