import { useState, useEffect } from 'react';
import { Upload, Image, Video, Music, FileText, X, Loader2, Plus, Folder, Link, ExternalLink, Paperclip } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import DashboardLayout from '../components/dashboard/DashboardLayout';
import api from '../services/api';
import { useToast } from '../hooks/useToast';
import Tooltip from '../components/common/Tooltip';
import Toast from '../components/common/Toast';
import RequireEditAccess from '../components/common/RequireEditAccess';

const CAMPAIGN_CATEGORIES = [
  'Tickets',
  'Restaurant Menus',
  'Products',
  'Events',
  'Marketing',
  'Education',
  'Healthcare',
  'Real Estate',
  'Travel',
  'Entertainment',
  'Business Cards',
  'Other',
];

const UploadPage = () => {
  const navigate = useNavigate();
  const { toasts, showToast, removeToast } = useToast();
  const [uploadType, setUploadType] = useState(null);
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState(null);
  const [preview, setPreview] = useState(null);
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [content, setContent] = useState('');

  // Button fields for TEXT content
  const [buttonText, setButtonText] = useState('');
  const [buttonUrl, setButtonUrl] = useState('');

  // Document attachments for TEXT content
  const [attachments, setAttachments] = useState([]);
  const [uploadingAttachment, setUploadingAttachment] = useState(false);

  // Embed fields
  const [embedUrl, setEmbedUrl] = useState('');
  const [embedType, setEmbedType] = useState('');

  // Campaign selection state
  const [campaigns, setCampaigns] = useState([]);
  const [selectedCampaignId, setSelectedCampaignId] = useState('');
  const [loadingCampaigns, setLoadingCampaigns] = useState(true);
  const [showCreateCampaignModal, setShowCreateCampaignModal] = useState(false);
  const [newCampaignData, setNewCampaignData] = useState({
    name: '',
    description: '',
    category: '',
  });
  const [creatingCampaign, setCreatingCampaign] = useState(false);

  // Fetch campaigns on mount
  useEffect(() => {
    fetchCampaigns();
  }, []);

  useEffect(() => {
    return () => {
    };
  }, []);

  const fetchCampaigns = async () => {
    try {
      setLoadingCampaigns(true);
      const response = await api.get('/campaigns');
      if (response.data.status === 'success') {
        setCampaigns(response.data.campaigns);
        if (response.data.campaigns.length > 0 && !selectedCampaignId) {
          setSelectedCampaignId(response.data.campaigns[0].id);
        }
      }
    } catch (error) {
      console.error('Failed to fetch campaigns:', error);
    } finally {
      setLoadingCampaigns(false);
    }
  };

  const handleCreateCampaign = async (e) => {
    e.preventDefault();
    
    if (!newCampaignData.name) {
      showToast('Please enter campaign name', 'error');
      return;
    }

    setCreatingCampaign(true);

    try {
      const response = await api.post('/campaigns', newCampaignData);
      if (response.data.status === 'success') {
        const newCampaign = response.data.campaign;
        setCampaigns([newCampaign, ...campaigns]);
        setSelectedCampaignId(newCampaign.id);
        setShowCreateCampaignModal(false);
        setNewCampaignData({ name: '', description: '', category: '' });
        showToast('Campaign created successfully!', 'success');
      }
    } catch (error) {
      console.error('Failed to create campaign:', error);
      showToast('Failed to create campaign', 'error');
    } finally {
      setCreatingCampaign(false);
    }
  };

  const simulateProgress = (startProgress, endProgress, duration) => {
    return new Promise((resolve) => {
      const steps = 50;
      const increment = (endProgress - startProgress) / steps;
      const stepDuration = duration / steps;
      let currentProgress = startProgress;

      const interval = setInterval(() => {
        currentProgress += increment;
        if (currentProgress >= endProgress) {
          setUploadProgress(endProgress);
          clearInterval(interval);
          resolve();
        } else {
          setUploadProgress(currentProgress);
        }
      }, stepDuration);
    });
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (file) => {
    setSelectedFile(file);
    
    if (file.type.startsWith('image/')) {
      setUploadType('IMAGE');
      const reader = new FileReader();
      reader.onload = (e) => setPreview(e.target.result);
      reader.readAsDataURL(file);
    } else if (file.type.startsWith('video/')) {
      setUploadType('VIDEO');
      const reader = new FileReader();
      reader.onload = (e) => setPreview(e.target.result);
      reader.readAsDataURL(file);
    } else if (file.type.startsWith('audio/')) {
      setUploadType('AUDIO');
      setPreview(null);
    } else {
      setUploadType('OTHER');
      setPreview(null);
    }
  };

  const handleFileUpload = async (e) => {
    e.preventDefault();
    
    if (!title) {
      showToast('Please enter a title', 'error');
      return;
    }

    if (!selectedFile) {
      showToast('Please select a file', 'error');
      return;
    }

    // ✅ NEW: Validate button fields
    if (buttonText && !buttonUrl) {
      showToast('Please enter button URL', 'error');
      return;
    }
    if (buttonUrl && !buttonText) {
      showToast('Please enter button text', 'error');
      return;
    }

    if (!selectedCampaignId) {
      showToast('Please select a campaign', 'error');
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      await simulateProgress(0, 20, 500);

      const reader = new FileReader();
      reader.onload = async (e) => {
        const fileData = e.target.result;

        await simulateProgress(20, 40, 300);

        // ✅ NEW: Include buttonText, buttonUrl, and attachments
        const uploadPromise = api.post('/upload/file', {
          title,
          description,
          type: uploadType,
          fileData,
          fileName: selectedFile.name,
          fileSize: selectedFile.size,
          buttonText: buttonText || null,
          buttonUrl: buttonUrl || null,
          attachments: attachments.length > 0 ? attachments : null,
        });

        const progressPromise = simulateProgress(40, 95, 2000);

        const [response] = await Promise.all([uploadPromise, progressPromise]);

        setUploadProgress(100);

        if (response.data.status === 'success') {
          const itemId = response.data.item.id;

          await api.post('/campaigns/assign', {
            itemId,
            campaignId: selectedCampaignId,
          });

          showToast('File uploaded and added to campaign!', 'success');
          
          setTimeout(() => {
            setTitle('');
            setDescription('');
            setSelectedFile(null);
            setPreview(null);
            setUploadType(null);
            setUploadProgress(0);
            setButtonText('');
            setButtonUrl('');
            setAttachments([]);
            navigate('/dashboard/campaigns');
          }, 1000);
        }
      };
      
      reader.readAsDataURL(selectedFile);
    } catch (error) {
      console.error('Upload error:', error);
      showToast(error.response?.data?.message || 'Failed to upload file', 'error');
      setUploadProgress(0);
      setUploading(false);
    }
  };

  const handleTextPost = async (e) => {
    e.preventDefault();

    if (!title || !content) {
      showToast('Please enter title and content', 'error');
      return;
    }

    // Validate button fields
    if (buttonText && !buttonUrl) {
      showToast('Please enter button URL', 'error');
      return;
    }
    if (buttonUrl && !buttonText) {
      showToast('Please enter button text', 'error');
      return;
    }

    if (!selectedCampaignId) {
      showToast('Please select a campaign', 'error');
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      await simulateProgress(0, 30, 300);

      // Include button fields and attachments
      const uploadPromise = api.post('/upload/text', {
        title,
        description,
        content,
        buttonText: buttonText || null,
        buttonUrl: buttonUrl || null,
        attachments: attachments.length > 0 ? attachments : null,
      });

      const progressPromise = simulateProgress(30, 95, 1000);

      const [response] = await Promise.all([uploadPromise, progressPromise]);

      setUploadProgress(100);

      if (response.data.status === 'success') {
        const itemId = response.data.item.id;

        await api.post('/campaigns/assign', {
          itemId,
          campaignId: selectedCampaignId,
        });

        showToast('Text post created and added to campaign!', 'success');
        
        setTimeout(() => {
          setTitle('');
          setDescription('');
          setContent('');
          setButtonText('');
          setButtonUrl('');
          setAttachments([]);
          setUploadType(null);
          setUploadProgress(0);
          navigate('/dashboard/campaigns');
        }, 1000);
      }
    } catch (error) {
      console.error('Text post error:', error);
      showToast(error.response?.data?.message || 'Failed to create text post', 'error');
      setUploadProgress(0);
    } finally {
      setUploading(false);
    }
  };

  const handleEmbedPost = async (e) => {
    e.preventDefault();

    if (!title || !embedUrl) {
      showToast('Please enter title and embed URL', 'error');
      return;
    }

    // Validate URL
    try {
      new URL(embedUrl);
    } catch (error) {
      showToast('Please enter a valid URL', 'error');
      return;
    }

    if (!selectedCampaignId) {
      showToast('Please select a campaign', 'error');
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      await simulateProgress(0, 30, 300);

      // Convert URL to embed format
      const convertedEmbedUrl = convertToEmbedUrl(embedUrl);

      const uploadPromise = api.post('/upload/embed', {
        title,
        description,
        embedUrl: convertedEmbedUrl, // Use converted URL
        embedType,
      });

      const progressPromise = simulateProgress(30, 95, 1000);

      const [response] = await Promise.all([uploadPromise, progressPromise]);

      setUploadProgress(100);

      if (response.data.status === 'success') {
        const itemId = response.data.item.id;

        await api.post('/campaigns/assign', {
          itemId,
          campaignId: selectedCampaignId,
        });

        showToast('Embed created and added to campaign!', 'success');
        
        setTimeout(() => {
          setTitle('');
          setDescription('');
          setEmbedUrl('');
          setEmbedType('');
          setUploadType(null);
          setUploadProgress(0);
          navigate('/dashboard/campaigns');
        }, 1000);
      }
    } catch (error) {
      console.error('Embed creation error:', error);
      showToast(error.response?.data?.message || 'Failed to create embed', 'error');
      setUploadProgress(0);
    } finally {
      setUploading(false);
    }
  };

  const detectEmbedType = (url) => {
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
      setEmbedType('YouTube');
      return 'YouTube Video';
    } else if (url.includes('vimeo.com')) {
      setEmbedType('Vimeo');
      return 'Vimeo Video';
    } else if (url.includes('soundcloud.com')) {
      setEmbedType('SoundCloud');
      return 'SoundCloud Audio';
    } else if (url.includes('spotify.com')) {
      setEmbedType('Spotify');
      return 'Spotify Playlist/Track';
    } else if (url.includes('drive.google.com')) {
      setEmbedType('Google Drive');
      return 'Google Drive Document';
    } else if (url.includes('docs.google.com')) {
      setEmbedType('Google Docs');
      return 'Google Document';
    } else if (url.includes('sheets.google.com')) {
      setEmbedType('Google Sheets');
      return 'Google Spreadsheet';
    } else if (url.includes('slides.google.com')) {
      setEmbedType('Google Slides');
      return 'Google Presentation';
    } else {
      setEmbedType('External');
      return 'External Content';
    }
  };

  // Convert YouTube URLs to embed format
  const convertToEmbedUrl = (url) => {
    if (!url) return url;

    // YouTube short URL: https://youtu.be/VIDEO_ID
    if (url.includes('youtu.be/')) {
      const videoId = url.split('youtu.be/')[1]?.split('?')[0]?.split('&')[0];
      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`;
      }
    }

    // YouTube watch URL: https://www.youtube.com/watch?v=VIDEO_ID
    if (url.includes('youtube.com/watch')) {
      const urlParams = new URLSearchParams(url.split('?')[1]);
      const videoId = urlParams.get('v');
      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`;
      }
    }

    // YouTube embed URL (already correct)
    if (url.includes('youtube.com/embed/')) {
      return url;
    }

    // Vimeo: https://vimeo.com/VIDEO_ID → https://player.vimeo.com/video/VIDEO_ID
    if (url.includes('vimeo.com/') && !url.includes('player.vimeo.com')) {
      const videoId = url.split('vimeo.com/')[1]?.split('?')[0]?.split('/')[0];
      if (videoId) {
        return `https://player.vimeo.com/video/${videoId}`;
      }
    }

    // Google Drive: Convert to preview format
    if (url.includes('drive.google.com/file/d/')) {
      const fileId = url.split('/d/')[1]?.split('/')[0];
      if (fileId) {
        return `https://drive.google.com/file/d/${fileId}/preview`;
      }
    }

    // Google Docs: Add /preview if not present
    if (url.includes('docs.google.com/document/d/') && !url.includes('/preview')) {
      const docId = url.split('/d/')[1]?.split('/')[0];
      if (docId) {
        return `https://docs.google.com/document/d/${docId}/preview`;
      }
    }

    // Google Sheets: Add /preview if not present
    if (url.includes('docs.google.com/spreadsheets/d/') && !url.includes('/preview')) {
      const sheetId = url.split('/d/')[1]?.split('/')[0];
      if (sheetId) {
        return `https://docs.google.com/spreadsheets/d/${sheetId}/preview`;
      }
    }

    // Return original URL if no conversion needed
    return url;
  };

  const handleAttachmentUpload = async (e) => {
    const files = Array.from(e.target.files);
    
    if (files.length === 0) return;

    // Validate file size (max 10MB per file)
    const maxSize = 10 * 1024 * 1024; // 10MB
    const oversizedFiles = files.filter(f => f.size > maxSize);
    
    if (oversizedFiles.length > 0) {
      showToast('Some files are larger than 10MB and were skipped', 'error');
      return;
    }

    // Max 5 attachments
    if (attachments.length + files.length > 5) {
      showToast('Maximum 5 attachments allowed', 'error');
      return;
    }

    setUploadingAttachment(true);

    try {
      // Convert files to base64 for storage
      const uploadPromises = files.map(async (file) => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            resolve({
              name: file.name,
              url: e.target.result, // Base64 data
              size: file.size,
              type: file.type,
            });
          };
          reader.readAsDataURL(file);
        });
      });

      const uploadedFiles = await Promise.all(uploadPromises);
      
      setAttachments([...attachments, ...uploadedFiles]);
      showToast(`${uploadedFiles.length} document(s) added successfully!`, 'success');
    } catch (error) {
      console.error('Attachment error:', error);
      showToast('Failed to add attachments', 'error');
    } finally {
      setUploadingAttachment(false);
    }
  };

  const handleRemoveAttachment = (index) => {
    const newAttachments = attachments.filter((_, i) => i !== index);
    setAttachments(newAttachments);
  };

  const CampaignSelector = () => (
    <div className="mb-6">
      <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
        Select Campaign *
        <Tooltip content="Choose which campaign this content belongs to" />
      </label>
      {loadingCampaigns ? (
        <div className="flex items-center justify-center py-4">
          <Loader2 className="animate-spin text-primary" size={24} />
        </div>
      ) : campaigns.length === 0 ? (
        <div className="text-center py-6 bg-purple-50 rounded-lg border border-purple-200">
          <Folder className="mx-auto mb-3 text-primary" size={32} />
          <p className="text-gray-700 mb-4">No campaigns yet. Create your first campaign!</p>
          <button
            type="button"
            onClick={() => setShowCreateCampaignModal(true)}
            className="gradient-btn text-white px-6 py-3 rounded-lg font-semibold inline-flex items-center gap-2"
          >
            <Plus size={20} />
            <span>Create Campaign</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <select
            value={selectedCampaignId}
            onChange={(e) => setSelectedCampaignId(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
            required
          >
            <option value="">-- Select a campaign --</option>
            {campaigns.map((campaign) => (
              <option key={campaign.id} value={campaign.id}>
                {campaign.name} {campaign.category && `(${campaign.category})`}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => setShowCreateCampaignModal(true)}
            className="w-full px-4 py-3 border-2 border-primary text-primary rounded-lg font-semibold hover:bg-purple-50 transition flex items-center justify-center gap-2"
          >
            <Plus size={20} />
            <span>Create New Campaign</span>
          </button>
        </div>
      )}
    </div>
  );

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-primary mb-2">Upload Content</h1>
        <p className="text-secondary mb-8">Upload images, videos, audio files, or create text posts</p>

        {!uploadType && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
              <button
                onClick={() => setUploadType('IMAGE')}
                className="p-6 bg-white rounded-xl border-2 border-gray-200 hover:border-primary hover:bg-purple-50 transition-all"
              >
                <Image className="mx-auto mb-3 text-primary" size={32} />
                <span className="block font-semibold text-gray-700">Images</span>
              </button>
              <button
                onClick={() => setUploadType('VIDEO')}
                className="p-6 bg-white rounded-xl border-2 border-gray-200 hover:border-primary hover:bg-purple-50 transition-all"
              >
                <Video className="mx-auto mb-3 text-primary" size={32} />
                <span className="block font-semibold text-gray-700">Videos</span>
              </button>
              <button
                onClick={() => setUploadType('AUDIO')}
                className="p-6 bg-white rounded-xl border-2 border-gray-200 hover:border-primary hover:bg-purple-50 transition-all"
              >
                <Music className="mx-auto mb-3 text-primary" size={32} />
                <span className="block font-semibold text-gray-700">Audio</span>
              </button>
              <button
                onClick={() => setUploadType('TEXT')}
                className="p-6 bg-white rounded-xl border-2 border-gray-200 hover:border-primary hover:bg-purple-50 transition-all"
              >
                <FileText className="mx-auto mb-3 text-primary" size={32} />
                <span className="block font-semibold text-gray-700">Text</span>
              </button>
              <button
                onClick={() => setUploadType('EMBED')}
                className="p-6 bg-white rounded-xl border-2 border-gray-200 hover:border-primary hover:bg-purple-50 transition-all"
              >
                <Link className="mx-auto mb-3 text-primary" size={32} />
                <span className="block font-semibold text-gray-700">Embed Link</span>
              </button>
            </div>

            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`border-4 border-dashed rounded-2xl p-12 text-center transition-all ${
                dragActive ? 'border-primary bg-purple-50' : 'border-gray-300'
              }`}
            >
              <Upload className="mx-auto mb-4 text-primary" size={48} />
              <p className="text-xl font-semibold text-gray-700 mb-2">
                Drag and drop your files here
              </p>
              <p className="text-gray-500 mb-6">or click to browse</p>
              <input
                type="file"
                onChange={(e) => e.target.files[0] && handleFileSelect(e.target.files[0])}
                className="hidden"
                id="file-upload"
              />
              <label
                htmlFor="file-upload"
                className="gradient-btn text-white px-6 py-3 rounded-lg font-semibold cursor-pointer inline-block"
              >
                Browse Files
              </label>
            </div>
          </>
        )}

        {/* TEXT UPLOAD FORM WITH BUTTON FEATURE AND ATTACHMENTS */}
        {uploadType === 'TEXT' && (
          <form onSubmit={handleTextPost} className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-primary">Create Text Post</h3>
              <button
                type="button"
                onClick={() => {
                  setUploadType(null);
                  setTitle('');
                  setDescription('');
                  setContent('');
                  setButtonText('');
                  setButtonUrl('');
                  setAttachments([]);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={24} />
              </button>
            </div>

            <div className="space-y-6">
              <CampaignSelector />

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  Title *
                  <Tooltip content="Give your text post a clear, descriptive title" />
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="Enter title"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  Description (Optional)
                  <Tooltip content="Add optional details about this text post" />
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="Add a description"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  Content *
                  <Tooltip content="Write your text content here - plain text only" />
                </label>
                <textarea
                  id="content-textarea"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={10}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                  placeholder="Write your content here..."
                  required
                />
              </div>

              {/* CUSTOM BUTTON SECTION - NO PREVIEW */}
              <div className="border-t border-gray-200 pt-6">
                <div className="bg-gradient-to-br from-purple-50 to-violet-50 border border-purple-200 rounded-xl p-6">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-lg">
                        <ExternalLink size={24} className="text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-primary mb-2">
                        🔗 Add Custom Button (Optional)
                      </h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Add a professional call-to-action button that appears with your text content. 
                        Perfect for "Visit Website", "Learn More", "Contact Us", etc.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Button Text
                      </label>
                      <input
                        type="text"
                        value={buttonText}
                        onChange={(e) => setButtonText(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="e.g., Visit Website"
                        maxLength={50}
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        What the button says (max 50 characters)
                      </p>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Button URL
                      </label>
                      <input
                        type="url"
                        value={buttonUrl}
                        onChange={(e) => setButtonUrl(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="https://example.com"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Where the button links to (must start with https://)
                      </p>
                    </div>
                  </div>

                  {buttonText && !buttonUrl && (
                    <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-yellow-800">
                        ⚠️ Please enter a button URL
                      </p>
                    </div>
                  )}
                  {buttonUrl && !buttonText && (
                    <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-yellow-800">
                        ⚠️ Please enter button text
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* DOCUMENT ATTACHMENTS SECTION */}
              <div className="border-t border-gray-200 pt-6">
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200 rounded-xl p-6">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg">
                        <Paperclip size={24} className="text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-blue-600 mb-2">
                        📎 Attach Documents (Optional)
                      </h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Upload PDF, Word, Excel, images, or other documents to display with your text content.
                        Max 5 files, 10MB each.
                      </p>
                    </div>
                  </div>

                  {/* Upload Button */}
                  <div className="mb-4">
                    <label className="cursor-pointer inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all">
                      <Paperclip size={18} />
                      <span>{uploadingAttachment ? 'Processing...' : 'Upload Documents'}</span>
                      <input
                        type="file"
                        multiple
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,image/*"
                        onChange={handleAttachmentUpload}
                        className="hidden"
                        disabled={uploadingAttachment || attachments.length >= 5}
                      />
                    </label>
                    <p className="text-xs text-gray-500 mt-2">
                      Accepted: PDF, Word, Excel, PowerPoint, Images, Text files
                    </p>
                  </div>

                  {/* Attached Files List */}
                  {attachments.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-sm font-semibold text-gray-700">
                        Attached Files ({attachments.length}/5):
                      </p>
                      {attachments.map((file, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-3 bg-white border border-blue-200 rounded-lg"
                        >
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                              <Paperclip size={18} className="text-blue-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-gray-900 truncate">
                                {file.name}
                              </p>
                              <p className="text-xs text-gray-500">
                                {(file.size / 1024).toFixed(1)} KB
                              </p>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveAttachment(index)}
                            className="flex-shrink-0 ml-2 text-red-500 hover:text-red-700 p-2"
                          >
                            <X size={18} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {attachments.length >= 5 && (
                    <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-yellow-800">
                        ⚠️ Maximum 5 attachments reached
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {uploading && uploadProgress > 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-gray-700">Creating post...</span>
                    <span className="text-sm font-bold text-primary">{Math.round(uploadProgress)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-primary to-secondary h-full rounded-full transition-all duration-300 ease-out"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-600 mt-2">Please wait while we create your post...</p>
                </div>
              )}

              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setUploadType(null);
                    setTitle('');
                    setDescription('');
                    setContent('');
                    setButtonText('');
                    setButtonUrl('');
                    setAttachments([]);
                  }}
                  className="flex-1 px-6 py-3 border border-gray-300 rounded-lg font-semibold hover:bg-gray-50 transition-all"
                  disabled={uploading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploading || !selectedCampaignId}
                  className="flex-1 gradient-btn text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {uploading ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 className="animate-spin" size={20} />
                      Creating...
                    </span>
                  ) : (
                    'Create Text Post'
                  )}
                </button>
              </div>
            </div>
          </form>
        )}

        {uploadType && uploadType !== 'TEXT' && !selectedFile && (
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-primary">Upload {uploadType}</h3>
              <button
                type="button"
                onClick={() => {
                  setUploadType(null);
                  setTitle('');
                  setDescription('');
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={24} />
              </button>
            </div>

            <CampaignSelector />

            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`border-4 border-dashed rounded-2xl p-12 text-center transition-all ${
                dragActive ? 'border-primary bg-purple-50' : 'border-gray-300'
              }`}
            >
              <Upload className="mx-auto mb-4 text-primary" size={48} />
              <p className="text-xl font-semibold text-gray-700 mb-2">
                Drag and drop your {uploadType.toLowerCase()} file here
              </p>
              <p className="text-gray-500 mb-6">or click to browse</p>
              <input
                type="file"
                accept={
                  uploadType === 'IMAGE' ? 'image/*' :
                  uploadType === 'VIDEO' ? 'video/*' :
                  uploadType === 'AUDIO' ? 'audio/*' : '*'
                }
                onChange={(e) => e.target.files[0] && handleFileSelect(e.target.files[0])}
                className="hidden"
                id="file-upload-selected"
              />
              <label
                htmlFor="file-upload-selected"
                className="gradient-btn text-white px-6 py-3 rounded-lg font-semibold cursor-pointer inline-block"
              >
                Browse Files
              </label>
            </div>
          </div>
        )}

        {uploadType && uploadType !== 'TEXT' && selectedFile && (
          <form onSubmit={handleFileUpload} className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-primary">Upload {uploadType}</h3>
              <button
                type="button"
                onClick={() => {
                  setUploadType(null);
                  setSelectedFile(null);
                  setPreview(null);
                  setTitle('');
                  setDescription('');
                  setButtonText('');
                  setButtonUrl('');
                  setAttachments([]);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={24} />
              </button>
            </div>

            <div className="space-y-6">
              <CampaignSelector />

              {preview && (uploadType === 'IMAGE' || uploadType === 'VIDEO') && (
                <div className="mb-6">
                  {uploadType === 'IMAGE' && (
                    <img src={preview} alt="Preview" className="w-full max-h-64 object-contain rounded-lg" />
                  )}
                  {uploadType === 'VIDEO' && (
                    <video src={preview} controls className="w-full max-h-64 rounded-lg" />
                  )}
                </div>
              )}

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  Title *
                  <Tooltip content="Give your media file a clear, descriptive title" />
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="Enter title"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  Description (Optional)
                  <Tooltip content="Add optional details about this media file" />
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="Add a description"
                />
              </div>

              {/* ✅ NEW: CUSTOM BUTTON SECTION FOR ALL MEDIA TYPES */}
              <div className="border-t border-gray-200 pt-6">
                <div className="bg-gradient-to-br from-purple-50 to-violet-50 border border-purple-200 rounded-xl p-6">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-lg">
                        <ExternalLink size={24} className="text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-primary mb-2">
                        🔗 Add Custom Button (Optional)
                      </h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Add a professional call-to-action button that appears with your {uploadType.toLowerCase()} content. 
                        Perfect for "Visit Website", "Learn More", "Contact Us", etc.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Button Text
                      </label>
                      <input
                        type="text"
                        value={buttonText}
                        onChange={(e) => setButtonText(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="e.g., Visit Website"
                        maxLength={50}
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        What the button says (max 50 characters)
                      </p>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Button URL
                      </label>
                      <input
                        type="url"
                        value={buttonUrl}
                        onChange={(e) => setButtonUrl(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="https://example.com"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Where the button links to (must start with https://)
                      </p>
                    </div>
                  </div>

                  {buttonText && !buttonUrl && (
                    <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-yellow-800">
                        ⚠️ Please enter a button URL
                      </p>
                    </div>
                  )}
                  {buttonUrl && !buttonText && (
                    <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-yellow-800">
                        ⚠️ Please enter button text
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* ✅ NEW: DOCUMENT ATTACHMENTS SECTION FOR ALL MEDIA TYPES */}
              <div className="border-t border-gray-200 pt-6">
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200 rounded-xl p-6">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg">
                        <Paperclip size={24} className="text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-blue-600 mb-2">
                        📎 Attach Documents (Optional)
                      </h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Upload PDF, Word, Excel, images, or other documents to display with your {uploadType.toLowerCase()} content.
                        Max 5 files, 10MB each.
                      </p>
                    </div>
                  </div>

                  {/* Upload Button */}
                  <div className="mb-4">
                    <label className="cursor-pointer inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all">
                      <Paperclip size={18} />
                      <span>{uploadingAttachment ? 'Processing...' : 'Upload Documents'}</span>
                      <input
                        type="file"
                        multiple
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,image/*"
                        onChange={handleAttachmentUpload}
                        className="hidden"
                        disabled={uploadingAttachment || attachments.length >= 5}
                      />
                    </label>
                    <p className="text-xs text-gray-500 mt-2">
                      Accepted: PDF, Word, Excel, PowerPoint, Images, Text files
                    </p>
                  </div>

                  {/* Attached Files List */}
                  {attachments.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-sm font-semibold text-gray-700">
                        Attached Files ({attachments.length}/5):
                      </p>
                      {attachments.map((file, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-3 bg-white border border-blue-200 rounded-lg"
                        >
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                              <Paperclip size={18} className="text-blue-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-gray-900 truncate">
                                {file.name}
                              </p>
                              <p className="text-xs text-gray-500">
                                {(file.size / 1024).toFixed(1)} KB
                              </p>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveAttachment(index)}
                            className="flex-shrink-0 ml-2 text-red-500 hover:text-red-700 p-2"
                          >
                            <X size={18} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {attachments.length >= 5 && (
                    <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-yellow-800">
                        ⚠️ Maximum 5 attachments reached
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="text-sm text-gray-600 bg-gray-50 p-4 rounded-lg">
                <p><strong>File:</strong> {selectedFile.name}</p>
                <p><strong>Size:</strong> {(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
              </div>

              {uploading && uploadProgress > 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-gray-700">Uploading...</span>
                    <span className="text-sm font-bold text-primary">{Math.round(uploadProgress)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-primary to-secondary h-full rounded-full transition-all duration-300 ease-out"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-600 mt-2">Please wait while we upload your file...</p>
                </div>
              )}

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => {
                    setUploadType(null);
                    setSelectedFile(null);
                    setPreview(null);
                    setTitle('');
                    setDescription('');
                    setButtonText('');
                    setButtonUrl('');
                    setAttachments([]);
                  }}
                  className="flex-1 px-6 py-3 border border-gray-300 rounded-lg font-semibold hover:bg-gray-50 transition-all"
                  disabled={uploading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploading || !selectedCampaignId}
                  className="flex-1 gradient-btn text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {uploading ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 className="animate-spin" size={20} />
                      Uploading...
                    </span>
                  ) : (
                    'Upload File'
                  )}
                </button>
              </div>
            </div>
          </form>
        )}

        {/* EMBED UPLOAD FORM */}
        {uploadType === 'EMBED' && (
          <form onSubmit={handleEmbedPost} className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-primary">Embed External Content</h3>
              <button
                type="button"
                onClick={() => {
                  setUploadType(null);
                  setTitle('');
                  setDescription('');
                  setEmbedUrl('');
                  setEmbedType('');
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={24} />
              </button>
            </div>

            {/* Info Box - Beautiful Card Design */}
            <div className="mb-6 bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50 border-2 border-purple-200 rounded-2xl p-6 shadow-xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-purple-600 via-blue-600 to-cyan-600 rounded-2xl flex items-center justify-center shadow-lg transform hover:scale-105 transition-transform">
                  <Link size={28} className="text-white" />
                </div>
                <div>
                  <h4 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                    Supported Platforms
                  </h4>
                  <p className="text-sm text-gray-600">Embed content from these sources</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {/* YouTube */}
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">▶️</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">YouTube</p>
                    <p className="text-xs text-gray-500">Videos</p>
                  </div>
                </div>

                {/* Vimeo */}
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🎬</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">Vimeo</p>
                    <p className="text-xs text-gray-500">Videos</p>
                  </div>
                </div>

                {/* Google Drive */}
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">📁</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">Google Drive</p>
                    <p className="text-xs text-gray-500">Files</p>
                  </div>
                </div>

                {/* Google Docs */}
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">📄</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">Google Docs</p>
                    <p className="text-xs text-gray-500">Documents</p>
                  </div>
                </div>

                {/* Google Sheets */}
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">📊</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">Google Sheets</p>
                    <p className="text-xs text-gray-500">Spreadsheets</p>
                  </div>
                </div>

                {/* SoundCloud */}
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🎵</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">SoundCloud</p>
                    <p className="text-xs text-gray-500">Audio</p>
                  </div>
                </div>

                {/* Spotify */}
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🎧</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">Spotify</p>
                    <p className="text-xs text-gray-500">Playlists</p>
                  </div>
                </div>

                {/* Custom iFrame */}
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🔗</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">Custom iFrame</p>
                    <p className="text-xs text-gray-500">Any Embed</p>
                  </div>
                </div>

                {/* External Links */}
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🌐</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">External Links</p>
                    <p className="text-xs text-gray-500">Websites</p>
                  </div>
                </div>
              </div>

              <div className="mt-4 p-3 bg-white rounded-lg border border-purple-200">
                <p className="text-xs text-gray-600 flex items-start gap-2">
                  <span className="text-purple-600 font-bold">💡</span>
                  <span><strong>Pro Tip:</strong> Make sure your embedded content is set to "Public" or "Anyone with the link" for Google Drive/Docs files.</span>
                </p>
              </div>
            </div>

            <div className="space-y-6">
              <CampaignSelector />

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  Embed URL * 
                  <Tooltip content="Paste the share/embed link from YouTube, Vimeo, Google Drive, etc." />
                </label>
                <input
                  type="url"
                  value={embedUrl}
                  onChange={(e) => {
                    setEmbedUrl(e.target.value);
                    if (e.target.value) {
                      detectEmbedType(e.target.value);
                    }
                  }}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="https://youtube.com/watch?v=... or https://drive.google.com/file/d/..."
                  required
                />
                {embedUrl && embedType && (
                  <div className="mt-2 flex items-center gap-2 text-sm">
                    <div className="px-3 py-1 bg-green-100 text-green-800 rounded-full font-semibold">
                      ✓ Detected: {embedType}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  Title *
                  <Tooltip content="Give your embedded content a descriptive title" />
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="e.g., Product Demo Video, Company Presentation, etc."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  Description (Optional)
                  <Tooltip content="Add optional details about this embedded content" />
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                  placeholder="Add a description..."
                />
              </div>

              {/* Preview Box */}
              {embedUrl && (
                <div className="border-t border-gray-200 pt-6">
                  <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
                    <h4 className="text-sm font-bold text-gray-700 mb-3">📋 Embed Preview:</h4>
                    <div className="bg-white p-4 rounded-lg border border-gray-300">
                      <p className="text-sm text-gray-600 break-all">{embedUrl}</p>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      This content will be embedded and viewable by anyone with the QR code or link.
                    </p>
                  </div>
                </div>
              )}

              {uploading && uploadProgress > 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-gray-700">Creating embed...</span>
                    <span className="text-sm font-bold text-primary">{Math.round(uploadProgress)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-primary to-secondary h-full rounded-full transition-all duration-300 ease-out"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => {
                    setUploadType(null);
                    setTitle('');
                    setDescription('');
                    setEmbedUrl('');
                    setEmbedType('');
                  }}
                  className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition"
                  disabled={uploading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 gradient-btn text-white px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={uploading || !title || !embedUrl}
                >
                  {uploading ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 className="animate-spin" size={18} />
                      Creating...
                    </span>
                  ) : (
                    'Create Embed'
                  )}
                </button>
              </div>
            </div>
          </form>
        )}

        {showCreateCampaignModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-8 max-w-md w-full">
              <h2 className="text-2xl font-bold text-primary mb-6">Create New Campaign</h2>
              <form onSubmit={handleCreateCampaign} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                    Campaign Name *
                    <Tooltip content="Give your campaign a clear, descriptive name" />
                  </label>
                  <input
                    type="text"
                    value={newCampaignData.name}
                    onChange={(e) => setNewCampaignData({ ...newCampaignData, name: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="e.g., Summer Sale 2024"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                    Category
                    <Tooltip content="Choose a category to organize your campaigns" />
                  </label>
                  <select
                    value={newCampaignData.category}
                    onChange={(e) => setNewCampaignData({ ...newCampaignData, category: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="">Select a category</option>
                    {CAMPAIGN_CATEGORIES.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                    Description
                    <Tooltip content="Add optional details about this campaign's purpose" />
                  </label>
                  <textarea
                    value={newCampaignData.description}
                    onChange={(e) => setNewCampaignData({ ...newCampaignData, description: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent h-24 resize-none"
                    placeholder="Optional description..."
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowCreateCampaignModal(false);
                      setNewCampaignData({ name: '', description: '', category: '' });
                    }}
                    className="flex-1 px-6 py-3 border border-gray-300 rounded-lg font-semibold hover:bg-gray-50 transition-all"
                    disabled={creatingCampaign}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 gradient-btn text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50"
                    disabled={creatingCampaign}
                  >
                    {creatingCampaign ? (
                      <span className="flex items-center justify-center gap-2">
                        <Loader2 className="animate-spin" size={20} />
                        Creating...
                      </span>
                    ) : (
                      'Create'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {toasts.map((toast) => (
          <Toast
            key={toast.id}
            message={toast.message}
            type={toast.type}
            onClose={() => removeToast(toast.id)}
          />
        ))}
      </div>
    </DashboardLayout>
  );
};

const ProtectedUploadPage = () => (
  <RequireEditAccess>
    <UploadPage />
  </RequireEditAccess>
);

export default ProtectedUploadPage;