import { useState, useEffect } from 'react';
import { UserPlus, Mail, Trash2, AlertCircle, Loader2, RefreshCw, Clock, CheckCircle, XCircle, X, Edit2 } from 'lucide-react';
import DashboardLayout from '../components/dashboard/DashboardLayout';
import Toast from '../components/common/Toast';
import useAuthStore from '../store/authStore';
import api from '../services/api';

const TeamPage = () => {
  const { user, setUser } = useAuthStore();
  const [teamMembers, setTeamMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviting, setInviting] = useState(false);
  const [resendingId, setResendingId] = useState(null);
  const [updatingRoleId, setUpdatingRoleId] = useState(null); // ✅ NEW: Track which member's role is being updated
  const [formData, setFormData] = useState({
    email: '',
    role: 'VIEWER',
    message: '',
  });
  const [error, setError] = useState('');
  const [showWarningPopup, setShowWarningPopup] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [memberToDelete, setMemberToDelete] = useState(null);

  // Toast State
  const [toast, setToast] = useState({ show: false, message: '', type: 'success' });

  const showToast = (message, type = 'success') => {
    setToast({ show: true, message, type });
  };

  const closeToast = () => {
    setToast({ show: false, message: '', type: 'success' });
  };

  useEffect(() => {
    document.title = 'Contributors Management | Outbound Impact';
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      const userRes = await api.get('/auth/me');
      if (userRes.data.status === 'success') {
        setUser(userRes.data.user);
        await fetchTeamMembers();
      }
    } catch (error) {
      console.error('Failed to fetch initial data:', error);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const fetchTeamMembers = async () => {
    try {
      const response = await api.get('/team');
      if (response.data.status === 'success') {
        setTeamMembers(response.data.teamMembers);
      }
    } catch (error) {
      console.error('Failed to fetch team members:', error);
    }
  };

  const handleInvite = async (e) => {
    e.preventDefault();
    setError('');
    setInviting(true);

    try {
      const response = await api.post('/team/invite', formData);
      if (response.data.status === 'success') {
        setTeamMembers([response.data.teamMember, ...teamMembers]);
        setShowInviteModal(false);
        setFormData({ email: '', role: 'VIEWER', message: '' });
        showToast('Contributor invited successfully! Invitation email sent.', 'success');
      }
    } catch (error) {
      console.error('Failed to invite contributor:', error);
      
      const errorData = error.response?.data;
      if (errorData?.code === 'EMAIL_ALREADY_REGISTERED') {
        setShowWarningPopup(true);
      } else {
        setError(errorData?.message || 'Failed to invite contributor');
      }
    } finally {
      setInviting(false);
    }
  };

  // ✅ NEW: Handle role change
  const handleRoleChange = async (memberId, newRole, currentRole) => {
    // Don't update if role hasn't changed
    if (newRole === currentRole) return;

    setUpdatingRoleId(memberId);
    
    try {
      const response = await api.put(`/team/${memberId}/role`, { role: newRole });
      
      if (response.data.status === 'success') {
        // Update local state
        setTeamMembers(teamMembers.map(member => 
          member.id === memberId 
            ? { ...member, role: newRole }
            : member
        ));
        
        showToast(`Role updated to ${newRole} successfully!`, 'success');
      }
    } catch (error) {
      console.error('Failed to update role:', error);
      showToast(
        error.response?.data?.message || 'Failed to update role. Please try again.', 
        'error'
      );
      
      // Revert the change in UI by re-fetching
      fetchTeamMembers();
    } finally {
      setUpdatingRoleId(null);
    }
  };

  const handleResend = async (id) => {
    setResendingId(id);
    try {
      const response = await api.post(`/team/${id}/resend`);
      if (response.data.status === 'success') {
        showToast('Invitation resent successfully!', 'success');
      }
    } catch (error) {
      console.error('Failed to resend invitation:', error);
      showToast('Failed to resend invitation', 'error');
    } finally {
      setResendingId(null);
    }
  };

  const handleRemove = (member) => {
    setMemberToDelete(member);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!memberToDelete) return;

    try {
      await api.delete('/team/' + memberToDelete.id);
      setTeamMembers(teamMembers.filter(m => m.id !== memberToDelete.id));
      showToast('Team member removed successfully!', 'success');
    } catch (error) {
      console.error('Failed to remove team member:', error);
      showToast('Failed to remove team member', 'error');
    } finally {
      setShowDeleteConfirm(false);
      setMemberToDelete(null);
    }
  };

  const cancelDelete = () => {
    setShowDeleteConfirm(false);
    setMemberToDelete(null);
  };

  const getStatusBadge = (status) => {
    const badges = {
      PENDING: {
        icon: Clock,
        color: 'bg-yellow-100 text-yellow-800',
        text: 'Pending'
      },
      ACCEPTED: {
        icon: CheckCircle,
        color: 'bg-green-100 text-green-800',
        text: 'Accepted'
      },
      DECLINED: {
        icon: XCircle,
        color: 'bg-red-100 text-red-800',
        text: 'Declined'
      }
    };

    const badge = badges[status] || badges.PENDING;
    const Icon = badge.icon;

    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${badge.color}`}>
        <Icon size={14} />
        {badge.text}
      </span>
    );
  };

  // ✅ NEW: Get role icon
  const getRoleIcon = (role) => {
    const icons = {
      VIEWER: '👁️',
      EDITOR: '✏️',
      ADMIN: '👑'
    };
    return icons[role] || '👤';
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center h-64">
          <Loader2 className="animate-spin text-primary mb-4" size={48} />
          <p className="text-gray-600">Loading contributors data...</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      {/* Toast Notification */}
      {toast.show && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={closeToast}
        />
      )}

      <div className="space-y-6">
        {/* Header Section - Fully Responsive */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex-1">
            <h1 className="text-2xl sm:text-3xl font-bold text-primary mb-1 sm:mb-2">
              Contributors Management
            </h1>
            <p className="text-sm sm:text-base text-secondary">
              Manage your team members and permissions
            </p>
          </div>
          <button
            onClick={() => {
              setShowInviteModal(true);
              setError('');
            }}
            className="gradient-btn text-white px-4 py-2.5 sm:px-6 sm:py-3 rounded-lg font-semibold flex items-center justify-center gap-2 hover:shadow-lg transition-all text-sm sm:text-base whitespace-nowrap"
          >
            <UserPlus size={18} className="sm:w-5 sm:h-5" />
            Invite Contributor
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-center gap-3">
            <AlertCircle className="text-red-600 flex-shrink-0" size={20} />
            <p className="text-red-800 font-medium">{error}</p>
          </div>
        )}

        {teamMembers.length === 0 ? (
          <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg p-6 sm:p-8 md:p-12 text-center border border-gray-100">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
              <UserPlus size={32} className="text-white sm:w-10 sm:h-10" />
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-primary mb-2 sm:mb-3">No Team Members Yet</h3>
            <p className="text-sm sm:text-base text-secondary mb-4 sm:mb-6">
              Invite contributor to collaborate on your content.
            </p>
            <button
              onClick={() => {
                setShowInviteModal(true);
                setError('');
              }}
              className="gradient-btn text-white px-5 py-2.5 sm:px-6 sm:py-3 rounded-lg font-semibold inline-flex items-center gap-2 hover:shadow-lg transition-all text-sm sm:text-base"
            >
              <UserPlus size={18} className="sm:w-5 sm:h-5" />
              Invite Your First Contributor
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg overflow-hidden border border-gray-100">
            {/* Desktop Table View - Hidden on Mobile */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-4 lg:px-6 py-3 lg:py-4 text-left text-xs lg:text-sm font-semibold text-gray-700">Member</th>
                    <th className="px-4 lg:px-6 py-3 lg:py-4 text-left text-xs lg:text-sm font-semibold text-gray-700">Role</th>
                    <th className="px-4 lg:px-6 py-3 lg:py-4 text-left text-xs lg:text-sm font-semibold text-gray-700">Status</th>
                    <th className="px-4 lg:px-6 py-3 lg:py-4 text-left text-xs lg:text-sm font-semibold text-gray-700">Invited</th>
                    <th className="px-4 lg:px-6 py-3 lg:py-4 text-left text-xs lg:text-sm font-semibold text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {teamMembers.map((member) => (
                    <tr key={member.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 lg:px-6 py-3 lg:py-4">
                        <div className="flex items-center gap-2 lg:gap-3">
                          <div className="w-8 h-8 lg:w-10 lg:h-10 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold text-sm lg:text-base flex-shrink-0">
                            {member.email[0].toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <p className="font-medium text-gray-900 text-sm lg:text-base truncate">{member.email}</p>
                            <p className="text-xs text-gray-500">Team Member</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 lg:px-6 py-3 lg:py-4">
                        {/* ✅ NEW: Editable Role Dropdown */}
                        <div className="relative">
                          <select
                            value={member.role}
                            onChange={(e) => handleRoleChange(member.id, e.target.value, member.role)}
                            disabled={updatingRoleId === member.id}
                            className={`
                              px-3 py-1.5 pr-8 bg-purple-50 text-primary rounded-lg text-xs lg:text-sm font-medium 
                              border-2 border-transparent hover:border-primary focus:border-primary focus:outline-none 
                              cursor-pointer transition-all appearance-none
                              ${updatingRoleId === member.id ? 'opacity-50 cursor-not-allowed' : ''}
                            `}
                            style={{
                              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%23800080'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`,
                              backgroundRepeat: 'no-repeat',
                              backgroundPosition: 'right 0.5rem center',
                              backgroundSize: '1rem'
                            }}
                          >
                            <option value="VIEWER">👁️ Viewer</option>
                            <option value="EDITOR">✏️ Editor</option>
                            <option value="ADMIN">👑 Admin</option>
                          </select>
                          {updatingRoleId === member.id && (
                            <div className="absolute right-2 top-1/2 -translate-y-1/2">
                              <Loader2 className="animate-spin text-primary" size={14} />
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 lg:px-6 py-3 lg:py-4">
                        {getStatusBadge(member.status)}
                      </td>
                      <td className="px-4 lg:px-6 py-3 lg:py-4 text-gray-600 text-xs lg:text-sm">
                        {new Date(member.createdAt).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })}
                      </td>
                      <td className="px-4 lg:px-6 py-3 lg:py-4">
                        <div className="flex items-center gap-2">
                          {member.status === 'PENDING' && (
                            <button
                              onClick={() => handleResend(member.id)}
                              disabled={resendingId === member.id}
                              className="text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1 transition-colors text-xs lg:text-sm disabled:opacity-50"
                              title="Resend invitation"
                            >
                              {resendingId === member.id ? (
                                <Loader2 className="animate-spin" size={14} />
                              ) : (
                                <RefreshCw size={14} />
                              )}
                              <span className="hidden lg:inline">Resend</span>
                            </button>
                          )}
                          <button
                            onClick={() => handleRemove(member)}
                            className="text-red-600 hover:text-red-700 font-medium flex items-center gap-1 transition-colors text-xs lg:text-sm"
                          >
                            <Trash2 size={14} />
                            <span className="hidden lg:inline">Remove</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card View - Hidden on Desktop */}
            <div className="md:hidden divide-y divide-gray-200">
              {teamMembers.map((member) => (
                <div key={member.id} className="p-4 hover:bg-gray-50 transition-colors">
                  {/* Member Info */}
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                      {member.email[0].toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 text-sm break-all">{member.email}</p>
                      <p className="text-xs text-gray-500 mt-0.5">Team Member</p>
                    </div>
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-2 gap-3 mb-3">
                    {/* Role - Editable */}
                    <div>
                      <p className="text-xs font-medium text-gray-500 mb-2">Role</p>
                      <div className="relative">
                        <select
                          value={member.role}
                          onChange={(e) => handleRoleChange(member.id, e.target.value, member.role)}
                          disabled={updatingRoleId === member.id}
                          className={`
                            w-full px-3 py-1.5 pr-8 bg-purple-50 text-primary rounded-lg text-sm font-medium
                            border-2 border-transparent hover:border-primary focus:border-primary focus:outline-none
                            cursor-pointer transition-all appearance-none
                            ${updatingRoleId === member.id ? 'opacity-50 cursor-not-allowed' : ''}
                          `}
                          style={{
                            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%23800080'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`,
                            backgroundRepeat: 'no-repeat',
                            backgroundPosition: 'right 0.5rem center',
                            backgroundSize: '1rem'
                          }}
                        >
                          <option value="VIEWER">👁️ Viewer</option>
                          <option value="EDITOR">✏️ Editor</option>
                          <option value="ADMIN">👑 Admin</option>
                        </select>
                        {updatingRoleId === member.id && (
                          <div className="absolute right-2 top-1/2 -translate-y-1/2">
                            <Loader2 className="animate-spin text-primary" size={14} />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Status */}
                    <div>
                      <p className="text-xs font-medium text-gray-500 mb-1">Status</p>
                      {getStatusBadge(member.status)}
                    </div>
                  </div>

                  {/* Invited Date */}
                  <div className="mb-3">
                    <p className="text-xs font-medium text-gray-500 mb-1">Invited</p>
                    <p className="text-sm text-gray-600">
                      {new Date(member.createdAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-3 border-t border-gray-100">
                    {member.status === 'PENDING' && (
                      <button
                        onClick={() => handleResend(member.id)}
                        disabled={resendingId === member.id}
                        className="flex-1 px-3 py-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-lg font-medium flex items-center justify-center gap-1.5 transition-colors text-sm disabled:opacity-50"
                      >
                        {resendingId === member.id ? (
                          <>
                            <Loader2 className="animate-spin" size={16} />
                            <span>Sending...</span>
                          </>
                        ) : (
                          <>
                            <RefreshCw size={16} />
                            <span>Resend</span>
                          </>
                        )}
                      </button>
                    )}
                    <button
                      onClick={() => handleRemove(member)}
                      className="flex-1 px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg font-medium flex items-center justify-center gap-1.5 transition-colors text-sm"
                    >
                      <Trash2 size={16} />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Simple Warning Popup */}
        {showWarningPopup && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[100] p-4">
            <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                    <AlertCircle className="text-red-600" size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">Email Already Registered</h3>
                  </div>
                </div>
                <button
                  onClick={() => setShowWarningPopup(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
              <p className="text-gray-700 mb-6">
                This email is already registered. Please use a different email ID.
              </p>
              <button
                onClick={() => setShowWarningPopup(false)}
                className="w-full gradient-btn text-white px-4 py-3 rounded-lg font-semibold hover:shadow-lg transition-all"
              >
                Got it
              </button>
            </div>
          </div>
        )}

        {/* Delete Confirmation Modal */}
        {showDeleteConfirm && memberToDelete && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[100] p-4">
            <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Trash2 className="text-red-600" size={24} />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-900 mb-1">Remove Team Member?</h3>
                  <p className="text-sm text-gray-600">
                    Are you sure you want to remove <strong>{memberToDelete.email}</strong> from your team?
                  </p>
                </div>
              </div>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-6">
                <p className="text-sm text-yellow-800">
                  ⚠️ This action cannot be undone. The team member will lose access immediately.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={cancelDelete}
                  className="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-all flex items-center justify-center gap-2"
                >
                  <Trash2 size={16} />
                  Remove
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Invite Modal - Fixed Scrolling */}
        {showInviteModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl max-w-md w-full max-h-[90vh] flex flex-col">
              {/* Header - Fixed at top */}
              <div className="p-4 sm:p-6 border-b border-gray-200 flex-shrink-0">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center flex-shrink-0">
                    <Mail size={20} className="text-white sm:w-6 sm:h-6" />
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-primary">Invite Contributor</h3>
                </div>
                <p className="text-xs sm:text-sm text-gray-600 ml-13 sm:ml-15">
                  Send a professional invitation email with a secure link
                </p>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6">
                <form onSubmit={handleInvite} id="invite-form">
                  {error && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4 flex items-center gap-2">
                      <AlertCircle size={16} className="text-red-600 flex-shrink-0" />
                      <p className="text-red-800 text-sm">{error}</p>
                    </div>
                  )}

                  <div className="space-y-3 sm:space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-sm sm:text-base"
                        placeholder="colleague@company.com"
                        required
                        disabled={inviting}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Role <span className="text-red-500">*</span>
                      </label>
                      <select
                        value={formData.role}
                        onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                        className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-sm sm:text-base"
                        disabled={inviting}
                      >
                        <option value="VIEWER">👁️ Viewer - Can view content</option>
                        <option value="EDITOR">✏️ Editor - Can edit content</option>
                        <option value="ADMIN">👑 Admin - Full access</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Personal Message (Optional)
                      </label>
                      <textarea
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none text-sm sm:text-base"
                        placeholder="e.g., Would love you to add content and stories about nan as we are putting together a memorial for her..."
                        rows={3}
                        disabled={inviting}
                        maxLength={500}
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        {formData.message.length}/500 characters • Explain why you're inviting this person
                      </p>
                    </div>
                  </div>
                </form>
              </div>

              {/* Footer - Fixed at bottom */}
              <div className="p-4 sm:p-6 border-t border-gray-200 flex-shrink-0">
                <div className="flex flex-col sm:flex-row gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setShowInviteModal(false);
                      setFormData({ email: '', role: 'VIEWER', message: '' });
                      setError('');
                    }}
                    className="flex-1 px-4 py-2.5 sm:px-6 sm:py-3 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-all text-sm sm:text-base"
                    disabled={inviting}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    form="invite-form"
                    className="flex-1 gradient-btn text-white px-4 py-2.5 sm:px-6 sm:py-3 rounded-lg font-semibold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm sm:text-base"
                    disabled={inviting}
                  >
                    {inviting ? (
                      <>
                        <Loader2 className="animate-spin" size={16} />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Mail size={16} />
                        Send Invitation
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default TeamPage;